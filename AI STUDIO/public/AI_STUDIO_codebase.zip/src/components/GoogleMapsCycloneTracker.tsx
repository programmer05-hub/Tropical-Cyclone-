import React, { useEffect, useRef, useState } from "react";
import {
  MapPin,
  Layers,
  Compass,
  Wind,
  Gauge,
  Navigation,
  Search,
  Shield,
  ZoomIn,
  ZoomOut,
  Crosshair,
  AlertTriangle,
  Info
} from "lucide-react";
import { CycloneData, Shelter } from "../types";

// Public demo key provisioned via CheckMapsDemoKeyEligibilityAndTos & GenerateMapsDemoKey
const GOOGLE_MAPS_API_KEY = "AIzaSyDC3toH5J2v09vITFEA6Vh1fN55Nfqm6KM";

interface GoogleMapsCycloneTrackerProps {
  cyclone: CycloneData;
  onSelectShelter?: (shelter: Shelter) => void;
}

export const GoogleMapsCycloneTracker: React.FC<GoogleMapsCycloneTrackerProps> = ({
  cyclone,
  onSelectShelter
}) => {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<any>(null);
  const cycloneMarkerRef = useRef<any>(null);
  const circlesRef = useRef<any[]>([]);
  const polylineRef = useRef<any>(null);
  const shelterMarkersRef = useRef<any[]>([]);

  const [mapLoaded, setMapLoaded] = useState(false);
  const [mapError, setMapError] = useState<string | null>(null);
  const [mapType, setMapType] = useState<"satellite" | "hybrid" | "roadmap" | "terrain">("hybrid");
  const [gmapsEngine, setGmapsEngine] = useState<"api" | "embed">("api");
  const [showWindRadii, setShowWindRadii] = useState(true);
  const [showForecastTrack, setShowForecastTrack] = useState(true);
  const [showShelters, setShowShelters] = useState(true);
  const [searchLocation, setSearchLocation] = useState("");
  const [distanceToCyclone, setDistanceToCyclone] = useState<number | null>(null);

  // Calculate distance between two lat/lon in km (Haversine formula)
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371; // Earth's radius in km
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Math.round(R * c);
  };

  // Load Google Maps JavaScript API
  useEffect(() => {
    if ((window as any).google && (window as any).google.maps) {
      setMapLoaded(true);
      return;
    }

    const scriptId = "google-maps-api-script";
    if (document.getElementById(scriptId)) {
      return;
    }

    const script = document.createElement("script");
    script.id = scriptId;
    script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=places,geometry`;
    script.async = true;
    script.defer = true;
    script.onload = () => {
      setMapLoaded(true);
    };
    script.onerror = () => {
      setMapError("Could not load Google Maps API. Please check network connection.");
    };

    document.head.appendChild(script);
  }, []);

  // Initialize Map Instance once loaded
  useEffect(() => {
    if (!mapLoaded || !mapContainerRef.current) return;
    const google = (window as any).google;
    if (!google || !google.maps) return;

    try {
      const map = new google.maps.Map(mapContainerRef.current, {
        center: { lat: cyclone.lat, lng: cyclone.lon },
        zoom: 7,
        mapTypeId: mapType,
        disableDefaultUI: false,
        zoomControl: true,
        streetViewControl: false,
        fullscreenControl: true,
        mapTypeControl: false,
        styles: [
          {
            featureType: "water",
            elementType: "geometry",
            stylers: [{ color: "#0a1e38" }]
          }
        ]
      });

      mapInstanceRef.current = map;
      updateMapLayers(map);
    } catch (err: any) {
      console.error("Map initialization error:", err);
      setMapError(err.message || "Failed to initialize Google Maps");
    }
  }, [mapLoaded]);

  // Update Cyclone Marker, Track, and Overlays whenever cyclone changes
  const updateMapLayers = (map: any) => {
    const google = (window as any).google;
    if (!google || !map) return;

    // 1. Clear existing overlays
    if (cycloneMarkerRef.current) cycloneMarkerRef.current.setMap(null);
    circlesRef.current.forEach((c) => c.setMap(null));
    circlesRef.current = [];
    if (polylineRef.current) polylineRef.current.setMap(null);
    shelterMarkersRef.current.forEach((m) => m.setMap(null));
    shelterMarkersRef.current = [];

    const cyclonePos = { lat: cyclone.lat, lng: cyclone.lon };

    // 2. Add the requested 🌀 cyclone symbol marker!
    // Create custom SVG marker with spinning / pulsating 🌀 icon
    const cycloneIcon = {
      url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
        <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">
          <circle cx="32" cy="32" r="30" fill="rgba(239, 68, 68, 0.25)" stroke="#ef4444" stroke-width="2"/>
          <circle cx="32" cy="32" r="20" fill="rgba(2, 6, 23, 0.85)" stroke="#ffffff" stroke-width="2"/>
          <text x="32" y="41" font-size="28" text-anchor="middle" font-family="sans-serif">🌀</text>
        </svg>
      `)}`,
      scaledSize: new google.maps.Size(64, 64),
      anchor: new google.maps.Point(32, 32)
    };

    const marker = new google.maps.Marker({
      position: cyclonePos,
      map: map,
      title: `Cyclone ${cyclone.name} (${cyclone.category})`,
      icon: cycloneIcon,
      animation: google.maps.Animation.DROP
    });

    // InfoWindow for Cyclone Eye
    const infoWindow = new google.maps.InfoWindow({
      content: `
        <div style="color: #0f172a; font-family: monospace; padding: 6px; max-width: 260px;">
          <div style="display: flex; align-items: center; gap: 6px; font-weight: bold; font-size: 14px; color: #dc2626;">
            <span style="font-size: 18px;">🌀</span> ${cyclone.name}
          </div>
          <div style="font-size: 11px; color: #475569; margin-top: 4px;">
            <strong>${cyclone.category}</strong>
          </div>
          <div style="font-size: 11px; margin-top: 6px; line-height: 1.5;">
            <div>• Lat/Lon: <strong>${cyclone.lat}°N, ${cyclone.lon}°E</strong></div>
            <div>• Sustained Winds: <strong style="color: #0284c7;">${cyclone.windSpeedKnots} kt</strong> (${Math.round(cyclone.windSpeedKnots * 1.852)} km/h)</div>
            <div>• Central Pressure: <strong>${cyclone.pressureHpa} hPa</strong></div>
            <div>• Surge Peak: <strong style="color: #dc2626;">${cyclone.surgeHeightMeters}m</strong></div>
            <div>• Target: <strong>${cyclone.targetRegion}</strong></div>
          </div>
        </div>
      `
    });

    marker.addListener("click", () => {
      infoWindow.open(map, marker);
    });

    cycloneMarkerRef.current = marker;

    // 3. Draw Wind Radii Circles (64kt, 50kt, 34kt)
    if (showWindRadii) {
      // 64-knot Hurricane Force Radius (~45 km)
      const circle64 = new google.maps.Circle({
        strokeColor: "#ef4444",
        strokeOpacity: 0.8,
        strokeWeight: 2,
        fillColor: "#ef4444",
        fillOpacity: 0.2,
        map: map,
        center: cyclonePos,
        radius: 45000 // meters
      });

      // 50-knot Storm Force Radius (~90 km)
      const circle50 = new google.maps.Circle({
        strokeColor: "#f97316",
        strokeOpacity: 0.7,
        strokeWeight: 1.5,
        fillColor: "#f97316",
        fillOpacity: 0.1,
        map: map,
        center: cyclonePos,
        radius: 90000
      });

      // 34-knot Gale Force Radius (~160 km)
      const circle34 = new google.maps.Circle({
        strokeColor: "#eab308",
        strokeOpacity: 0.6,
        strokeWeight: 1,
        fillColor: "#eab308",
        fillOpacity: 0.05,
        map: map,
        center: cyclonePos,
        radius: 160000
      });

      circlesRef.current = [circle64, circle50, circle34];
    }

    // 4. Draw Forecast Track Polyline
    if (showForecastTrack && cyclone.forecastCone) {
      const trackCoords = cyclone.forecastCone.map((fc) => ({
        lat: fc.lat,
        lng: fc.lon
      }));

      const trackPath = new google.maps.Polyline({
        path: trackCoords,
        geodesic: true,
        strokeColor: "#06b6d4",
        strokeOpacity: 0.9,
        strokeWeight: 3
      });

      trackPath.setMap(map);
      polylineRef.current = trackPath;
    }

    // 5. Add Inland Cyclone Shelters on Google Maps
    if (showShelters && cyclone.shelters) {
      cyclone.shelters.forEach((shelter) => {
        const shelterMarker = new google.maps.Marker({
          position: { lat: shelter.lat, lng: shelter.lon },
          map: map,
          title: shelter.name,
          icon: {
            url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
              <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
                <circle cx="16" cy="16" r="14" fill="#0d9488" stroke="#ffffff" stroke-width="2"/>
                <text x="16" y="21" font-size="14" text-anchor="middle" font-family="sans-serif" font-weight="bold" fill="#ffffff">S</text>
              </svg>
            `)}`,
            scaledSize: new google.maps.Size(32, 32),
            anchor: new google.maps.Point(16, 16)
          }
        });

        const shelterInfoWindow = new google.maps.InfoWindow({
          content: `
            <div style="color: #0f172a; font-family: monospace; padding: 4px; max-width: 220px;">
              <strong style="color: #0d9488; font-size: 13px;">${shelter.name}</strong>
              <div style="font-size: 11px; margin-top: 4px;">
                <div>• Capacity: <strong>${shelter.capacity.toLocaleString()}</strong></div>
                <div>• Elevation: <strong>+${shelter.elevationMeters}m MSL</strong></div>
                <div>• Status: <strong style="color: #059669;">${shelter.status}</strong></div>
              </div>
            </div>
          `
        });

        shelterMarker.addListener("click", () => {
          shelterInfoWindow.open(map, shelterMarker);
          onSelectShelter?.(shelter);
        });

        shelterMarkersRef.current.push(shelterMarker);
      });
    }

    // Center map on cyclone
    map.panTo(cyclonePos);
  };

  // Re-run layers when dependencies change
  useEffect(() => {
    if (mapInstanceRef.current) {
      updateMapLayers(mapInstanceRef.current);
    }
  }, [cyclone, showWindRadii, showForecastTrack, showShelters]);

  // Handle Map Type Change
  const handleMapTypeChange = (type: "satellite" | "hybrid" | "roadmap" | "terrain") => {
    setMapType(type);
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setMapTypeId(type);
    }
  };

  // Center on Cyclone
  const centerOnCyclone = () => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.panTo({ lat: cyclone.lat, lng: cyclone.lon });
      mapInstanceRef.current.setZoom(8);
    }
  };

  // Geocode location search
  const handleLocationSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchLocation.trim() || !mapInstanceRef.current) return;
    const google = (window as any).google;
    if (!google) return;

    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ address: searchLocation }, (results: any, status: any) => {
      if (status === "OK" && results[0]) {
        const loc = results[0].geometry.location;
        mapInstanceRef.current.panTo(loc);
        mapInstanceRef.current.setZoom(9);

        // Calculate distance from searched location to cyclone
        const dist = calculateDistance(cyclone.lat, cyclone.lon, loc.lat(), loc.lng());
        setDistanceToCyclone(dist);

        // Place temporary marker on searched city
        new google.maps.Marker({
          position: loc,
          map: mapInstanceRef.current,
          title: results[0].formatted_address,
          animation: google.maps.Animation.DROP
        });
      } else {
        alert("Location not found on Google Maps. Try another coastal city.");
      }
    });
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3 sm:p-5 shadow-2xl space-y-3 sm:space-y-4">
      {/* Header and Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-2 sm:p-2.5 rounded-xl bg-cyan-500/20 border border-cyan-400/40 text-cyan-300">
            <span className="text-xl">🌀</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-bold text-white tracking-wide">
                GOOGLE MAPS SATELLITE CYCLONE TRACKER
              </h2>
              <span className="px-2 py-0.5 rounded text-[9px] sm:text-[10px] font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
                LIVE GMAPS INTERFACE
              </span>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-400">
              Interactive Google Maps integration showing exact cyclone eye position 🌀 with wind radii & coastal infrastructure
            </p>
          </div>
        </div>

        {/* Map Type & Layer Controls */}
        <div className="flex flex-wrap items-center gap-2 text-xs font-mono w-full sm:w-auto justify-between sm:justify-start">
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 overflow-x-auto no-scrollbar">
            <button
              onClick={() => handleMapTypeChange("hybrid")}
              className={`px-2 sm:px-2.5 py-1 rounded-lg text-[11px] sm:text-xs transition ${
                mapType === "hybrid" ? "bg-cyan-500 text-slate-950 font-bold" : "text-slate-400 hover:text-white"
              }`}
            >
              Hybrid
            </button>
            <button
              onClick={() => handleMapTypeChange("satellite")}
              className={`px-2 sm:px-2.5 py-1 rounded-lg text-[11px] sm:text-xs transition ${
                mapType === "satellite" ? "bg-cyan-500 text-slate-950 font-bold" : "text-slate-400 hover:text-white"
              }`}
            >
              Satellite
            </button>
            <button
              onClick={() => handleMapTypeChange("terrain")}
              className={`px-2 sm:px-2.5 py-1 rounded-lg text-[11px] sm:text-xs transition ${
                mapType === "terrain" ? "bg-cyan-500 text-slate-950 font-bold" : "text-slate-400 hover:text-white"
              }`}
            >
              Terrain
            </button>
            <button
              onClick={() => handleMapTypeChange("roadmap")}
              className={`px-2 sm:px-2.5 py-1 rounded-lg text-[11px] sm:text-xs transition ${
                mapType === "roadmap" ? "bg-cyan-500 text-slate-950 font-bold" : "text-slate-400 hover:text-white"
              }`}
            >
              Roadmap
            </button>
          </div>

          <button
            onClick={centerOnCyclone}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs transition shadow-sm cursor-pointer ml-auto sm:ml-0"
          >
            <Crosshair className="w-3.5 h-3.5" />
            <span>Center on 🌀 Cyclone</span>
          </button>
        </div>
      </div>

      {/* Location Search Bar & Cyclone Proximity Tool */}
      <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <form onSubmit={handleLocationSearch} className="flex items-center gap-2 w-full sm:flex-1 sm:max-w-md">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchLocation}
              onChange={(e) => setSearchLocation(e.target.value)}
              placeholder="Search coastal city (e.g., Paradip, Puri, Kolkata, Houston)..."
              className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
            />
          </div>
          <button
            type="submit"
            className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded-lg transition shrink-0 cursor-pointer"
          >
            Find City
          </button>
        </form>

        <div className="flex flex-wrap items-center gap-2 sm:gap-4 text-slate-300 font-mono text-[11px]">
          {distanceToCyclone !== null && (
            <div className="px-2.5 py-1 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold">
              Distance to 🌀 Eye: {distanceToCyclone} km
            </div>
          )}
          <label className="flex items-center gap-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={showWindRadii}
              onChange={(e) => setShowWindRadii(e.target.checked)}
              className="accent-cyan-400"
            />
            <span>Wind Radii (34/50/64kt)</span>
          </label>
          <label className="flex items-center gap-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={showForecastTrack}
              onChange={(e) => setShowForecastTrack(e.target.checked)}
              className="accent-cyan-400"
            />
            <span>Forecast Track</span>
          </label>
          <label className="flex items-center gap-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={showShelters}
              onChange={(e) => setShowShelters(e.target.checked)}
              className="accent-cyan-400"
            />
            <span>Shelters (S)</span>
          </label>
        </div>

        {/* Engine switcher */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-mono">
          <button
            onClick={() => setGmapsEngine("api")}
            className={`px-2.5 py-1 rounded-lg transition ${
              gmapsEngine === "api" ? "bg-cyan-500 text-slate-950 font-bold" : "text-slate-400 hover:text-white"
            }`}
          >
            Maps JS API
          </button>
          <button
            onClick={() => setGmapsEngine("embed")}
            className={`px-2.5 py-1 rounded-lg transition ${
              gmapsEngine === "embed" ? "bg-cyan-500 text-slate-950 font-bold" : "text-slate-400 hover:text-white"
            }`}
          >
            Satellite Frame View
          </button>
        </div>
      </div>

      {/* Google Maps Container */}
      <div className="relative w-full h-[380px] sm:h-[480px] lg:h-[580px] xl:h-[640px] rounded-xl overflow-hidden border border-slate-700 shadow-inner bg-slate-950">
        {gmapsEngine === "embed" || mapError ? (
          /* Google Maps Interactive Satellite Frame Mode */
          <div className="relative w-full h-full">
            <iframe
              title="Google Maps Cyclone Eye View"
              src={`https://maps.google.com/maps?q=${cyclone.lat},${cyclone.lon}&t=${mapType === "roadmap" ? "m" : "k"}&z=7&ie=UTF8&iwloc=&output=embed`}
              className="w-full h-full border-0 filter brightness-90 contrast-105"
              loading="lazy"
            />

            {/* SUPERIMPOSED 🌀 CYCLONE SYMBOL MARKER AT EXACT COORDINATES */}
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
              <div className="relative flex items-center justify-center">
                {/* 64kt Hurricane Wind Radius Ring */}
                {showWindRadii && (
                  <>
                    <div className="absolute w-32 sm:w-44 h-32 sm:h-44 rounded-full border-2 border-dashed border-red-500/80 animate-ping opacity-30" />
                    <div className="absolute w-32 sm:w-44 h-32 sm:h-44 rounded-full border-2 border-red-500/70 bg-red-500/10" />
                    <div className="absolute w-52 sm:w-72 h-52 sm:h-72 rounded-full border border-orange-500/50 bg-orange-500/5" />
                    <div className="absolute w-72 sm:w-96 h-72 sm:h-96 rounded-full border border-yellow-500/40" />
                  </>
                )}

                {/* Pulsing Eye Core Beacon */}
                <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-full bg-slate-950/80 border-2 border-white shadow-2xl flex items-center justify-center pointer-events-auto cursor-pointer hover:scale-110 transition backdrop-blur-sm">
                  <span className="text-2xl sm:text-3xl animate-spin-slow select-none">🌀</span>
                </div>

                {/* Marker Tag */}
                <div className="absolute top-14 sm:top-16 bg-slate-950/95 border border-red-500/60 px-2 sm:px-3 py-0.5 sm:py-1 rounded-lg text-[10px] sm:text-xs font-mono font-bold text-white shadow-2xl whitespace-nowrap">
                  🌀 {cyclone.name} ({cyclone.category})
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Google Maps JS API Mode */
          <div className="relative w-full h-full">
            <div ref={mapContainerRef} className="w-full h-full" />
          </div>
        )}

        {/* Floating Cyclone Eye Location Badge */}
        <div className="absolute top-2 left-2 sm:top-3 sm:left-3 z-10 bg-slate-950/90 backdrop-blur-md px-2.5 sm:px-3.5 py-1.5 sm:py-2.5 rounded-xl border border-red-500/50 shadow-xl text-[10px] sm:text-xs font-mono text-slate-200 space-y-0.5 sm:space-y-1 max-w-[calc(100%-16px)] sm:max-w-xs">
          <div className="flex items-center gap-1.5 sm:gap-2 font-bold text-red-400">
            <span className="text-base sm:text-lg animate-spin-slow">🌀</span>
            <span>CYCLONE EYE LOCATION</span>
          </div>
          <div className="truncate">Storm: <strong className="text-white">{cyclone.name}</strong> ({cyclone.category})</div>
          <div>Coordinates: <strong className="text-cyan-300">{cyclone.lat}°N, {cyclone.lon}°E</strong></div>
          <div>Intensity: <strong className="text-amber-300">{cyclone.windSpeedKnots} kt</strong> • <strong>{cyclone.pressureHpa} hPa</strong></div>
          <div className="text-[9px] sm:text-[10px] text-slate-400 truncate">Landfall Target: {cyclone.targetRegion}</div>
        </div>

        {/* Legend */}
        <div className="absolute bottom-2 left-2 right-2 sm:left-auto sm:right-3 z-10 bg-slate-950/90 backdrop-blur-md px-2.5 sm:px-3 py-1.5 rounded-lg border border-slate-700 text-[9px] sm:text-[10px] font-mono text-slate-400 flex flex-wrap items-center gap-2 sm:gap-3 justify-center sm:justify-start">
          <div className="flex items-center gap-1">
            <span className="w-2 sm:w-2.5 h-2 sm:h-2.5 rounded-full bg-red-500 shrink-0" />
            <span>64kt Hurricane</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2 sm:w-2.5 h-2 sm:h-2.5 rounded-full bg-orange-500 shrink-0" />
            <span>50kt Storm</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2 sm:w-2.5 h-2 sm:h-2.5 rounded-full bg-yellow-400 shrink-0" />
            <span>34kt Gale</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2 sm:w-2.5 h-2 sm:h-2.5 rounded-full bg-teal-500 shrink-0" />
            <span>Shelters (S)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
